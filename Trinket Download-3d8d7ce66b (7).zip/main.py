№ 11
a, b, c = int(input()), int(input()), int(input())
if len(set((a,b,c)))==1:
  print('Равностаронний')
elif  len(set((a,b,c)))==2:
    print('Равнобедренный')
else:
  print('Равностаронний')
№ 12
a, b, c = int(input()), int(input()), int(input())
if a < b < c or a > b > c:
print(b)
elif b < c < a or b > c > a:
print(c)
else:
print(a)
№ 13
x = int(input())

if x == 2:
print(28)
elif (x < 8 and x % 2 == 0) or (x > 7 and x % 2 != 0):
print(30)
else:
print(31)
№ 14
m = int(input())
if m<=59:
print('Легкий вес')
elif m>=60 and m<=63:
print('Первый полусредний вес')
elif m>=64 and m<=68:
print('Полусредний вес')
№ 15
a, b, s = int(input()), int(input()), input()
if(b == 0 and s == '/'): print("На ноль делить нельзя!")
elif(s == '+'): print (a+b)
elif(s == '*'): print (a*b)
elif(s == '/'): print (a/b)
elif(s == '-'): print (a-b)
else: print("Неверная операция")