№ 6
a = int(input()) 
b = int(input()) 
print(min([a, b]))
№ 7
age = int(input())
if age <= 13:
print('детство')
elif 13 < age <= 24:
print('молодость')
elif 25 <= age <= 59:
print('зрелость')
else:
print('старость')
№ 8
a = float(input("Введите первое число: "))  
 
b = float(input("Введите второе число: "))  
 
c = float(input("Введите третье число: "))  
 
sum = 0  
 
if a > 0:  
    sum += a  
 
if b > 0:  
    sum += b  
  
if c > 0:  
    sum += c  

print("Сумма положительных чисел:", sum)
№ 9
x = int (input())
if (1000 <= x <= 9999) and (x % 7 == 0 or x % 17 == 0):
print("YES")
else:
print("NO")
№ 10
ear = int(input())

if (year % 4 == 0) and (year % 100 != 0) or (year % 400 == 0):
    print('YES')
else:
    print('NO')