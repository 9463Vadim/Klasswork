№ 1
a = input()
b = input()
if a == b:
print('Пароль принят')
else:
print('Пароль не принят')
№ 2
readln (a);`
` if a mod 2 = 0 then`
` writeln ('Заданное Вами число делится на 2, поэтому оно является чётным');`
` else`
` writeln ('Заданное Вами число не делится на 2 без остатка, поэтому оно является нечётным');`
№ 3
a = int(input())
if (a // 1000) + (a % 10) == (a % 1000 // 100) - (a % 100 // 10):
print('ДА')
else:
print('НЕТ')
№ 4
age = int(input("Введите возраст: ")) 

if age >= 18: 
 
    print("Доступ разрешён ")  
 
else: 
    print("Доступ запрещён")
№ 5
a = int(input())
b = int(input())
c = int(input())
if b - a == c - b:
print('YES')
else:
print('NO')